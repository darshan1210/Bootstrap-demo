import React from "react";
import './footer.scss'

function Footer() {
    return (
        <>
            <div className='footer'>
                <h5>Copyright&copy; 2000-2022 Yudiz inc. All Right Reserved</h5>
            </div>
        </>
    )
}

export default Footer